module.exports = {
    DB_URI: process.env.DB_URI,
    SECRET: process.env.SECRET
 }
